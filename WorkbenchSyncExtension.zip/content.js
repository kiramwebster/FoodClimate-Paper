// Mark extension installed synchronously on shared DOM
document.documentElement.dataset.workbenchExtension = "1.0";
window.dispatchEvent(new CustomEvent("WORKBENCH_EXTENSION_READY"));

// Maintain keep-alive port connection to prevent Chrome from sleeping the service worker
let keepAlivePort = null;
function setupKeepAlive() {
  try {
    keepAlivePort = chrome.runtime.connect({ name: "workbench-keepalive" });
    keepAlivePort.onMessage.addListener((msg) => {
      if (msg && msg.action === "COMPANION_WINDOW_CLOSED") {
        window.dispatchEvent(new CustomEvent("WORKBENCH_COMPANION_CLOSED"));
      }
    });
    keepAlivePort.onDisconnect.addListener(() => {
      keepAlivePort = null;
      setTimeout(setupKeepAlive, 1000);
    });
  } catch (e) {}
}
setupKeepAlive();

// Ping heartbeat every 20 seconds so background service worker never goes idle
setInterval(() => {
  if (keepAlivePort) {
    try {
      keepAlivePort.postMessage({ ping: true });
    } catch (e) {
      setupKeepAlive();
    }
  } else {
    setupKeepAlive();
  }
}, 20000);

// Check if companion window is still open
window.addEventListener("WORKBENCH_CHECK_COMPANION", () => {
  try {
    chrome.runtime.sendMessage({ action: "CHECK_COMPANION" }, (res) => {
      if (chrome.runtime.lastError) return;
      if (res && res.closed) {
        window.dispatchEvent(new CustomEvent("WORKBENCH_COMPANION_CLOSED"));
      }
    });
  } catch (e) {}
});

let lastNavUrl = "";
let lastNavTime = 0;

function handleNavigateRequest(url, bringToFront) {
  if (!url) return;
  const now = Date.now();
  if (url === lastNavUrl && (now - lastNavTime < 400)) {
    return; // Ignore duplicate calls in rapid succession
  }
  lastNavUrl = url;
  lastNavTime = now;

  const screenInfo = {
    availWidth: window.screen.availWidth || 1920,
    availHeight: window.screen.availHeight || 1080,
    availLeft: window.screen.availLeft !== undefined ? window.screen.availLeft : (window.screenLeft || 0),
    availTop: window.screen.availTop !== undefined ? window.screen.availTop : (window.screenTop || 0)
  };

  chrome.runtime.sendMessage({
    action: "NAVIGATE_COMPANION",
    url: url,
    bringToFront: Boolean(bringToFront),
    screen: screenInfo
  }, (res) => {
    if (chrome.runtime.lastError) return;
    if (res && res.closed) {
      window.dispatchEvent(new CustomEvent("WORKBENCH_COMPANION_CLOSED"));
    }
  });
}

// Listen for CustomEvents from the webpage
window.addEventListener("WORKBENCH_NAVIGATE_PAPER", (e) => {
  const detail = e.detail || {};
  handleNavigateRequest(detail.url, detail.bringToFront);
});

window.addEventListener("WORKBENCH_NAVIGATE_COMPANION", (e) => {
  const detail = e.detail || {};
  handleNavigateRequest(detail.url, detail.bringToFront);
});

// Also support postMessage as secondary fallback
window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  if (event.data && (event.data.type === "WORKBENCH_NAVIGATE_PAPER" || event.data.type === "WORKBENCH_NAVIGATE_COMPANION")) {
    handleNavigateRequest(event.data.url, event.data.bringToFront);
  }
});
