// Background service worker for managing the persistent full-form companion window
let companionWindowId = null;
let companionTabId = null;
let isSpawningWindow = false;
const workbenchPorts = new Set();

// Keep service worker permanently alive via port heartbeat while workbench tab is open
chrome.runtime.onConnect.addListener((port) => {
  if (port.name === "workbench-keepalive") {
    workbenchPorts.add(port);
    port.onDisconnect.addListener(() => {
      workbenchPorts.delete(port);
    });
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "NAVIGATE_COMPANION") {
    const targetUrl = msg.url;
    if (!targetUrl || targetUrl === "about:blank") return;

    const senderWindowId = sender && sender.tab ? sender.tab.windowId : null;
    navigateOrCreateCompanion(targetUrl, msg.bringToFront, msg.screen, senderWindowId, sendResponse);
    return true; // Keep async channel open
  }

  if (msg.action === "CHECK_COMPANION") {
    if (companionWindowId !== null) {
      chrome.windows.get(companionWindowId, (win) => {
        if (!chrome.runtime.lastError && win) {
          sendResponse({ open: true });
        } else {
          companionWindowId = null;
          companionTabId = null;
          sendResponse({ closed: true });
        }
      });
    } else {
      sendResponse({ closed: true });
    }
    return true;
  }
});

function tileSenderWindow(senderWindowId, screenInfo) {
  if (!senderWindowId || !screenInfo) return;
  const availW = screenInfo.availWidth || 1920;
  const availH = screenInfo.availHeight || 1080;
  const availLeft = screenInfo.availLeft !== undefined ? screenInfo.availLeft : 0;
  const availTop = screenInfo.availTop !== undefined ? screenInfo.availTop : 0;
  const leftW = Math.max(460, Math.min(600, Math.round(availW * 0.34)));

  chrome.windows.get(senderWindowId, (win) => {
    if (chrome.runtime.lastError || !win) return;
    if (win.state === "maximized" || win.state === "fullscreen") {
      chrome.windows.update(senderWindowId, { state: "normal" }, () => {
        chrome.windows.update(senderWindowId, {
          left: availLeft,
          top: availTop,
          width: leftW,
          height: availH
        });
      });
    } else {
      chrome.windows.update(senderWindowId, {
        state: "normal",
        left: availLeft,
        top: availTop,
        width: leftW,
        height: availH
      });
    }
  });
}

function navigateOrCreateCompanion(targetUrl, bringToFront, screenInfo, senderWindowId, callback) {
  if (companionWindowId !== null) {
    chrome.windows.get(companionWindowId, { populate: true }, (win) => {
      if (!chrome.runtime.lastError && win && win.tabs && win.tabs.length > 0) {
        // Target the active tab in the companion window
        const activeTab = win.tabs.find(t => t.active) || win.tabs[0];
        companionTabId = activeTab.id;

        chrome.tabs.update(companionTabId, { url: targetUrl }, (tab) => {
          if (bringToFront) {
            chrome.windows.update(companionWindowId, { focused: true });
            tileSenderWindow(senderWindowId, screenInfo);
          }
          if (callback) callback({ success: true, tabId: companionTabId });
        });
        return;
      }

      // Companion window was closed by the user!
      companionWindowId = null;
      companionTabId = null;
      notifyCompanionClosed();

      // Only re-create if the user explicitly clicked to open (bringToFront=true)!
      // Quiet Next/Prev navigation must NEVER spawn a new window!
      if (bringToFront) {
        spawnCompanionWindow(targetUrl, bringToFront, screenInfo, senderWindowId, callback);
      } else {
        if (callback) callback({ success: false, closed: true });
      }
    });
  } else {
    // Companion window is not open. Only spawn if explicit user click (bringToFront=true)!
    if (bringToFront) {
      spawnCompanionWindow(targetUrl, bringToFront, screenInfo, senderWindowId, callback);
    } else {
      notifyCompanionClosed();
      if (callback) callback({ success: false, closed: true });
    }
  }
}

function spawnCompanionWindow(url, bringToFront, screenInfo, senderWindowId, callback) {
  if (isSpawningWindow) {
    if (callback) callback({ success: true, inProgress: true });
    return;
  }
  isSpawningWindow = true;

  // Snap Workbench to left side of screen
  tileSenderWindow(senderWindowId, screenInfo);

  const availW = (screenInfo && screenInfo.availWidth) || 1920;
  const availH = (screenInfo && screenInfo.availHeight) || 1080;
  const availLeft = (screenInfo && screenInfo.availLeft !== undefined) ? screenInfo.availLeft : 0;
  const availTop = (screenInfo && screenInfo.availTop !== undefined) ? screenInfo.availTop : 0;
  const leftW = Math.max(460, Math.min(600, Math.round(availW * 0.34)));
  const rightW = availW - leftW;
  const rightLeft = availLeft + leftW;

  chrome.windows.create({
    url: url,
    type: "normal", // Full browser window with Back/Forward buttons and address bar!
    state: "normal",
    left: rightLeft,
    top: availTop,
    width: rightW,
    height: availH,
    focused: true
  }, (win) => {
    isSpawningWindow = false;
    if (win && win.tabs && win.tabs.length > 0) {
      companionWindowId = win.id;
      companionTabId = win.tabs[0].id;
      if (callback) callback({ success: true, tabId: companionTabId });
    }
  });
}

function notifyCompanionClosed() {
  workbenchPorts.forEach(port => {
    try {
      port.postMessage({ action: "COMPANION_WINDOW_CLOSED" });
    } catch(e) {}
  });
}

// Clean up state when reviewer explicitly closes the companion window or its tab
chrome.windows.onRemoved.addListener((winId) => {
  if (winId === companionWindowId) {
    companionWindowId = null;
    companionTabId = null;
    isSpawningWindow = false;
    notifyCompanionClosed();
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === companionTabId) {
    companionWindowId = null;
    companionTabId = null;
    isSpawningWindow = false;
    notifyCompanionClosed();
  }
});
